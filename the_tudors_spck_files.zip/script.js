// THE TUDORS — all page switching, category rendering and image viewer.
const people = {
 king: [
  {name:"Henry VIII",role:"King of England · 1509–1547",image:"https://commons.wikimedia.org/wiki/Special:FilePath/Henry%20VIII%20by%20Hans%20Holbein.jpg",alt:"Henry VIII by Hans Holbein",paras:[
   "Henry VIII became king in 1509 after the death of his father, Henry VII. He was the second monarch of the Tudor dynasty and initially celebrated as a promising, athletic, and highly educated Renaissance prince.",
   "His six marriages became central to his reign. His determination to secure an annulment from Catherine of Aragon contributed to England’s break with papal authority and the establishment of the monarch as head of the Church of England.",
   "Henry strengthened royal government, expanded the navy, and dissolved England’s monasteries. His reign reshaped religion and politics, while the succession passed to his children Edward VI, Mary I, and Elizabeth I."
  ]}
 ],
 wives:[
  {name:"Catherine of Aragon",role:"First wife · 1509–1533",image:"https://commons.wikimedia.org/wiki/Special:FilePath/Catherine%20of%20Aragon%20by%20Lucas%20Horenbout.jpg",alt:"Portrait of Catherine of Aragon",paras:[
   "Catherine was the daughter of Ferdinand II of Aragon and Isabella I of Castile. Before marrying Henry VIII, she had been married to his elder brother Arthur, Prince of Wales, who died in 1502.",
   "She married Henry in 1509 and served as queen for more than twenty years. Their surviving child was Mary, later Queen Mary I. Catherine was also appointed regent while Henry campaigned in France in 1513.",
   "Henry sought to end the marriage when no surviving son had been born. Catherine maintained that her marriage to Arthur had never been consummated and refused to accept the annulment, remaining a respected figure among many English people."
  ]},
  {name:"Anne Boleyn",role:"Second wife · 1533–1536",image:"https://commons.wikimedia.org/wiki/Special:FilePath/Anne%20Boleyn%2C%20by%20an%20unknown%20artist.jpg",alt:"Portrait traditionally identified as Anne Boleyn",paras:[
   "Anne Boleyn spent part of her youth at European courts, where she encountered Renaissance culture and religious debate. Her intelligence, confidence, and courtly presence attracted Henry VIII.",
   "She married Henry in 1533 after the king’s break with Rome. Their daughter Elizabeth was born that year. Anne’s position was politically influential but unstable as court factions competed for royal favour.",
   "In 1536 Anne was tried and executed after being accused of treason. The charges remain the subject of historical debate. Her daughter Elizabeth later became one of England’s most celebrated monarchs."
  ]},
  {name:"Jane Seymour",role:"Third wife · 1536–1537",image:"https://commons.wikimedia.org/wiki/Special:FilePath/Jane%20Seymour%2C%20Queen%20of%20England%20by%20Hans%20Holbein.jpg",alt:"Portrait of Jane Seymour",paras:[
   "Jane Seymour came from a well-connected English family and served in the households of Catherine of Aragon and Anne Boleyn. She became close to Henry during the political upheaval of 1536.",
   "Jane married Henry shortly after Anne Boleyn’s execution. In October 1537 she gave birth to Prince Edward, the long-awaited male heir who survived infancy.",
   "Jane died less than two weeks after Edward’s birth, probably from complications following childbirth. Henry later regarded her as his most beloved wife and was eventually buried beside her at Windsor."
  ]},
  {name:"Anne of Cleves",role:"Fourth wife · 1540",image:"https://commons.wikimedia.org/wiki/Special:FilePath/Anne%20of%20Cleves%20by%20Hans%20Holbein.jpg",alt:"Portrait of Anne of Cleves",paras:[
   "Anne was born into the ruling family of the Duchy of Cleves in the Holy Roman Empire. Her marriage to Henry was arranged as part of Thomas Cromwell’s plan to strengthen England’s Protestant alliances.",
   "The marriage took place in January 1540 but was annulled that July. Henry and Anne had not formed a marital relationship, and both agreed to the legal ending of the union.",
   "Anne accepted a generous settlement and remained in England. She was treated as the king’s sister, kept several residences, and outlived Henry and all his other wives."
  ]},
  {name:"Catherine Howard",role:"Fifth wife · 1540–1542",image:"https://commons.wikimedia.org/wiki/Special:FilePath/Catherine%20Howard%20by%20Hans%20Holbein.jpg",alt:"Portrait traditionally identified as Catherine Howard",paras:[
   "Catherine Howard was a young member of the powerful Howard family. She entered the royal household as a lady-in-waiting to Anne of Cleves and attracted Henry’s attention soon after his fourth marriage ended.",
   "She married Henry in 1540. Her time as queen was brief, and allegations about relationships before and during the marriage led to an investigation at court.",
   "Catherine was found guilty of treason and executed in 1542. Because surviving evidence is limited and some accounts were shaped by political interests, historians continue to examine the details of her story carefully."
  ]},
  {name:"Catherine Parr",role:"Sixth wife · 1543–1547",image:"https://commons.wikimedia.org/wiki/Special:FilePath/Catherine%20Parr%20by%20Master%20John.jpg",alt:"Portrait of Catherine Parr",paras:[
   "Catherine Parr was an educated English noblewoman who had already been widowed twice before marrying Henry VIII. She was interested in religious writing and became an influential figure at court.",
   "As queen, Catherine helped restore contact between Henry and his daughters Mary and Elizabeth. She also served as regent while Henry was on campaign in France in 1544 and published religious works under her own name.",
   "After Henry’s death in 1547, Catherine married Thomas Seymour. She died in 1548 after giving birth to a daughter. She was the only one of Henry’s six wives to publish books during her lifetime."
  ]}
 ],
 children:[
  {name:"Mary Tudor (Mary I)",role:"Queen of England · 1553–1558",image:"https://commons.wikimedia.org/wiki/Special:FilePath/Mary%20I%20of%20England.jpg",alt:"Portrait of Mary I",paras:[
   "Mary was the only surviving child of Henry VIII and Catherine of Aragon. She was raised as a princess and was once recognised as heir, but her status changed after Henry’s marriage to Anne Boleyn and the break with Rome.",
   "Mary became queen in 1553 after the short reign of her half-brother Edward VI. She married Philip of Spain and worked to restore Roman Catholicism in England, reversing many religious changes made under her father and brother.",
   "Her reign is remembered for the persecution of Protestants, which gave rise to the name “Bloody Mary.” Mary died in 1558 without an heir, and her half-sister Elizabeth succeeded her."
  ]},
  {name:"Elizabeth Tudor (Elizabeth I)",role:"Queen of England · 1558–1603",image:"https://commons.wikimedia.org/wiki/Special:FilePath/Elizabeth%20I%20in%20coronation%20robes.jpg",alt:"Elizabeth I in coronation robes",paras:[
   "Elizabeth was the daughter of Henry VIII and Anne Boleyn. Her mother’s execution and the political changes of Henry’s reign shaped Elizabeth’s uncertain childhood and complicated position in the succession.",
   "She became queen in 1558 and established a religious settlement that restored a Protestant Church of England while retaining some traditional forms of worship. Her government navigated foreign threats, court rivalries, and questions about marriage and succession.",
   "Elizabeth’s reign became known as the Elizabethan age, associated with maritime expansion and flourishing literature and theatre. She never married and died in 1603, bringing the Tudor dynasty to an end."
  ]},
  {name:"Edward Tudor (Edward VI)",role:"King of England · 1547–1553",image:"https://commons.wikimedia.org/wiki/Special:FilePath/Edward%20VI%20of%20England.jpg",alt:"Portrait of Edward VI",paras:[
   "Edward was the son of Henry VIII and Jane Seymour and the long-awaited male heir born during Henry’s lifetime. He became king at only nine years old after his father died in 1547.",
   "Because Edward was a child, leading nobles governed through a regency council. The country moved further in a Protestant direction, with major changes to worship and the publication of the Book of Common Prayer.",
   "Edward’s health declined and he died in 1553 at age fifteen. His attempt to alter the succession in favour of Lady Jane Grey led to a brief crisis, but Mary was recognised as queen."
  ]},
  {name:"Henry FitzRoy",role:"Duke of Richmond and Somerset · Illegitimate son",image:"https://commons.wikimedia.org/wiki/Special:FilePath/Henry%20FitzRoy%2C%20Duke%20of%20Richmond%20and%20Somerset.jpg",alt:"Portrait of Henry FitzRoy",paras:[
   "Henry FitzRoy was the acknowledged illegitimate son of Henry VIII and Elizabeth Blount. His surname, FitzRoy, means “son of the king,” making his royal paternity unmistakable.",
   "In 1525 he was created Duke of Richmond and Somerset and given important titles and responsibilities. His elevated status showed that Henry VIII valued him, although FitzRoy was not placed ahead of the king’s legitimate children in the succession.",
   "FitzRoy died in 1536, aged about seventeen, probably from an illness. His early death removed a possible alternative male Tudor heir at a time when the king’s legitimate succession remained uncertain."
  ]}
 ]
};
const categoryCopy={
 king:"Meet Henry VIII, the Tudor monarch whose marriages, policies, and break with Rome transformed the course of English history.",
 wives:"Six marriages shaped Henry VIII’s personal life and the politics of the Tudor court. Each queen had a different story, influence, and fate.",
 children:"Henry VIII’s legitimate children ruled England in turn, while his acknowledged son Henry FitzRoy held a prominent place at court."
};
const facts=[
"Henry VIII was not born as the expected heir. His older brother Arthur was first in line, but Arthur’s death in 1502 made Henry the future king.",
"Henry was only seventeen when he became king in 1509.",
"Henry VIII wrote music and poetry and was an accomplished sportsman in his youth.",
"The famous phrase “divorced, beheaded, died; divorced, beheaded, survived” is a later mnemonic, not a Tudor-era saying.",
"Only two of Henry’s six wives were executed: Anne Boleyn and Catherine Howard.",
"Anne of Cleves outlived Henry VIII and all five of his other wives.",
"Jane Seymour was the only wife to give Henry a male child who survived infancy.",
"Henry’s break with Rome was closely connected to his attempt to annul his marriage to Catherine of Aragon.",
"The Dissolution of the Monasteries transferred enormous wealth and land from religious institutions to the Crown and other owners.",
"Henry VIII’s flagship, the Mary Rose, sank in 1545 in the Solent. It was raised in 1982 and is now displayed in Portsmouth.",
"Henry FitzRoy was given the title Duke of Richmond and Somerset despite being born outside marriage.",
"Edward VI became king at nine years old and died at fifteen.",
"Mary I’s marriage to Philip of Spain made England part of a major European dynastic alliance, but Philip did not become king of England in his own right.",
"Elizabeth I’s reign lasted nearly forty-five years. She became known as the “Virgin Queen” and never married.",
"The Tudor dynasty ended in 1603 when Elizabeth I died without an heir. James VI of Scotland succeeded her as James I of England."
];
const imageItems=[
 {key:"henry",name:"Henry VIII",src:people.king[0].image},
 {key:"anne",name:"Anne Boleyn",src:people.wives[1].image},
 {key:"elizabeth",name:"Elizabeth I",src:people.children[1].image},
 ...people.wives.map((p,i)=>({key:"wife"+i,name:p.name,src:p.image})),
 ...people.children.map((p,i)=>({key:"child"+i,name:p.name,src:p.image}))
];
const $=s=>document.querySelector(s);
const $$=s=>[...document.querySelectorAll(s)];
let currentCategory="king",lightboxIndex=0,lastTouch=0;
function showView(name){
 $$(".view").forEach(v=>v.classList.toggle("active",v.id===name+"View"));
 $$(".nav-link").forEach(b=>b.classList.toggle("active",b.dataset.view===name));
 $("#mobileMenu").classList.remove("open");$("#menuToggle").setAttribute("aria-expanded","false");
 window.scrollTo({top:0,behavior:matchMedia("(prefers-reduced-motion: reduce)").matches?"auto":"smooth"});
}
function renderCategory(category){
 currentCategory=category;
 $$(".category-tab").forEach(b=>{const active=b.dataset.category===category;b.classList.toggle("active",active);b.setAttribute("aria-selected",String(active));});
 $("#categoryIntro").textContent=categoryCopy[category];
 $("#peopleGrid").innerHTML=people[category].map((p,i)=>`
  <article class="person-card" style="animation-delay:${i*75}ms">
   <div class="person-image" data-person-image="${encodeURIComponent(p.name)}" tabindex="0" role="button" aria-label="Enlarge portrait of ${p.name}">
    <span class="person-number">0${i+1}</span><img src="${p.image}" alt="${p.alt}" loading="lazy" onerror="this.src='https://images.unsplash.com/photo-1577083552431-6e5fd01aa342?auto=format&fit=crop&w=800&q=85'">
   </div>
   <div class="person-info"><span class="role">${p.role}</span><h3>${p.name}</h3>
    ${p.paras.map(par=>`<p>${par}</p>`).join("")}
   </div>
  </article>`).join("");
 $$("#peopleGrid .person-image").forEach((el)=>{
  const open=()=>openImageByName(decodeURIComponent(el.dataset.personImage));
  el.addEventListener("click",open);el.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();open();}});
 });
}
function renderFacts(){
 $("#factsGrid").innerHTML=facts.map((f,i)=>`<article class="fact-card" style="animation:cardIn .5s ${i*45}ms both"><span class="fact-number">${String(i+1).padStart(2,"0")}</span><p>${f}</p></article>`).join("");
}
function openImageByName(name){const idx=imageItems.findIndex(x=>x.name===name);if(idx>=0)openLightbox(idx);}
function openLightbox(index){
 lightboxIndex=(index+imageItems.length)%imageItems.length;const item=imageItems[lightboxIndex];
 $("#lightboxImage").src=item.src;$("#lightboxImage").alt=item.name;$("#lightboxCaption").textContent=item.name.toUpperCase();
 $("#lightbox").classList.add("open");$("#lightbox").setAttribute("aria-hidden","false");document.body.style.overflow="hidden";
}
function closeLightbox(){$("#lightbox").classList.remove("open");$("#lightbox").setAttribute("aria-hidden","true");document.body.style.overflow="";}
function moveLightbox(step){openLightbox(lightboxIndex+step);}
$$("[data-view]").forEach(btn=>btn.addEventListener("click",()=>showView(btn.dataset.view)));
$("#discoverBtn").addEventListener("click",()=>{showView("topics");renderCategory("king");});
$$(".category-tab").forEach(btn=>btn.addEventListener("click",()=>renderCategory(btn.dataset.category)));
$("#menuToggle").addEventListener("click",()=>{const open=$("#mobileMenu").classList.toggle("open");$("#menuToggle").setAttribute("aria-expanded",String(open));});
$("#lightboxClose").addEventListener("click",closeLightbox);
$("#lightboxPrev").addEventListener("click",()=>moveLightbox(-1));
$("#lightboxNext").addEventListener("click",()=>moveLightbox(1));
$("#lightbox").addEventListener("click",e=>{if(e.target.id==="lightbox")closeLightbox();});
document.addEventListener("keydown",e=>{if(!$("#lightbox").classList.contains("open"))return;if(e.key==="Escape")closeLightbox();if(e.key==="ArrowLeft")moveLightbox(-1);if(e.key==="ArrowRight")moveLightbox(1);});
let touchStartX=0;
$("#lightbox").addEventListener("touchstart",e=>{touchStartX=e.changedTouches[0].screenX;},{passive:true});
$("#lightbox").addEventListener("touchend",e=>{const delta=e.changedTouches[0].screenX-touchStartX;if(Math.abs(delta)>55)moveLightbox(delta>0?-1:1);},{passive:true});
// Pointer-based 3D tilt: disabled on touch-only devices to keep scrolling and taps natural.
if(window.matchMedia("(hover:hover) and (pointer:fine)").matches){
 $$(".floating-photo").forEach(card=>{
  card.addEventListener("pointermove",e=>{const r=card.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;card.style.transform=`perspective(900px) rotateX(${-y*12}deg) rotateY(${x*14}deg) translateZ(16px) scale(1.04)`;});
  card.addEventListener("pointerleave",()=>card.style.transform="");
 });
}
renderCategory("king");renderFacts();
